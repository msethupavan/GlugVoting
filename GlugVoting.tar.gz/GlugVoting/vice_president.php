<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Registration";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}
$count=0;
echo '<html><script>
var x=0;
function selected(){
x=document.election.i1.value;
if(x==0){
	alert("please select any one candidate or atleast none option");
	return false;
}
return true;
}
</script>
<style>h1 {
     font-size: 50px;
     text-shadow:4px 3px slateBlue;
    }</style>
<body><form name="election" action="" method="post" onSubmit="return selected();">
<h1 align="center">CHOOSE YOUR VICE PRESIDENT</h1>
<table align="center" width="100%">';
$sql="select name,regdno,image from details r join nominations n where r.Regd=n.regdno AND n.Vice>0";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	echo '<tr>';
    while($row = $result->fetch_assoc()) {
	echo '<td><label><img src="images/',$row['image'],'"alt="name of vice president" width="100px" height="100px" >','<br>','<input type="radio" name="i1" value="',$row['regdno'],'"/>',$row['name'],'</label>';
	echo '</td>';
	$count=$count+1;
	if($count==3){
		echo '</tr><tr>';
		$count=0;
	}
    }
}
echo '<td><label><img src="nota-india.jpg"alt="name of vice president" width="100px" height="100px" >','<br>','<input type="radio" name="i1" value="none"/>NOTA</label></td>';
echo '</tr></table>';
echo '<center><input type="submit" name="submit" value="Vote my Choice"/></center></form></body></html>';
if(isset($_POST['submit'])){
	$value=$_POST['i1'];
	echo $value;
	if($value!="none"){
		$insert="UPDATE nominations SET Vice=Vice+1 where regdno='$value'";
		$ins=$conn->query($insert);
	}
	if($ins)
		header('Location:treasurer.php');
}
?>
