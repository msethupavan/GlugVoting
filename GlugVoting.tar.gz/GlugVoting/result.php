<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Registration";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}
if(!isset($_POST['submit'])){
echo '<html>
<head>
<script>
function hide(){
	document.getElementById("cred").style.display="none";
	return true;
}
</script>
</head>
<body id="cred">
<center>
<h1>Results</h1>
<p>Enter admin name and password to know the results</p>
<form action="result.php" method="post" onSubmit="return hide();">
<table>
<tr><td>Name:</td>
<td><input type="text" name="admin" placeholder="admin"/></td></tr>
<tr><td>Password:</td>
<td><input type="text" name="password" placeholder="password"/></td></tr>
<tr><td><input type="submit" name="submit" value="View Result"/></td></tr>
</table>
</form>
</body>
</html>';
}
if(isset($_POST['submit'])){
if($_POST['admin']=="manasa"&&$_POST['password']="komali"){
$vote="select regdno from nominations where President=(select max(President) from nominations)";
$rv=$conn->query($vote);
if ($rv->num_rows > 0) {
    while($row = $rv->fetch_assoc()) {
	echo $row['regdno'],'<br>';
    }
}
$vote="select regdno from nominations where vice=(select max(vice) from nominations)";
$rv=$conn->query($vote);
if ($rv->num_rows > 0) {
    while($row = $rv->fetch_assoc()) {
	echo $row['regdno'],'<br>';

    }
}
$vote="select regdno from nominations where Treasurer=(select max(Treasurer) from nominations)";
$rv=$conn->query($vote);
if ($rv->num_rows > 0) {
    while($row = $rv->fetch_assoc()) {
	echo $row['regdno'],'<br>';
    }
}
$vote="select regdno from nominations where Technical=(select max(Technical) from nominations)";
$rv=$conn->query($vote);
if ($rv->num_rows > 0) {
    while($row = $rv->fetch_assoc()) {
	echo $row['regdno'],'<br>';
    }
}
$vote="select regdno from nominations where Organiser=(select max(Organiser) from nominations)";
$rv=$conn->query($vote);
if ($rv->num_rows > 0) {
    while($row = $rv->fetch_assoc()) {
	echo $row['regdno'],'<br>';
    }
}
$vote="select regdno from nominations where cultural=(select max(cultural) from nominations)";
$rv=$conn->query($vote);
if ($rv->num_rows > 0) {
    while($row = $rv->fetch_assoc()) {
	echo $row['regdno'];
    }
}
}
}
?>
