-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 24, 2017 at 06:54 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `ID` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `image` varchar(100) NOT NULL,
  `FatherOccupation` varchar(20) NOT NULL,
  `Regd` varchar(11) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `Department` varchar(20) NOT NULL,
  `JoinYear` year(4) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Contact` varchar(12) NOT NULL,
  `Locality` varchar(30) NOT NULL,
  `Known` varchar(255) NOT NULL,
  `Interested` varchar(255) NOT NULL,
  `Swecha` varchar(20) NOT NULL,
  `opinion` varchar(255) NOT NULL,
  `Projects` varchar(128) NOT NULL,
  `DateOfBirth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`ID`, `Name`, `image`, `FatherOccupation`, `Regd`, `Gender`, `Course`, `Department`, `JoinYear`, `Email`, `Contact`, `Locality`, `Known`, `Interested`, `Swecha`, `opinion`, `Projects`, `DateOfBirth`) VALUES
('', '', '', '', '', '', '', '', 0000, '', '', '', '', '', '', '--', '--', '0000-00-00'),
('10331A0563', 'vamsi', '10331A0563.png', 'doctor', '10331A0563', 'male', 'MTECH', '0', 2015, 'v@v.vam', '9876543210', 'vizianagaram', 'nothing', 'everything', 'yes', 'in need of swecha', 'BS', '1992-07-23'),
('14331A0554', 'm', '14331A0554.png', 'jhygasd', '14331A0554', 'male', 'BTECH', '0', 2015, 'a@a.com', '7656565656', 'vizianagaram', '', '', 'no', '--', '--', '2017-07-23'),
('15331A0497', 'uma shankaar', '15331A0497.jpg', 'electrician', '15331A0497', 'male', 'BTECH', 'ece', 2015, 'raj01101997@gmail.com', '9951746690', 'vizianagaram', 'c', 'html,java', 'yes', 'very interesting', 'FB', '1997-10-01'),
('15331A0555', 'm', '15331A0555.png', 'm', '15331A0555', 'female', 'BTECH', '0', 2014, 'a@a.com', '7656565656', 'vishakapataanam', 'j', 'lk', 'yes', 'jfjgfj', 'BS', '2017-07-23'),
('15331A0567', 'power star', '15331A0567.jpg', 'no background', '15331A0567', 'male', 'BTECH', 'cse', 2015, 'powerstar@gmail.com', '9876543211', 'other', 'every thing', 'every thing', 'yes', '', 'BS,SL,FB', '1971-02-09'),
('15331A0582', 'KUNDEM NAGA SAI TULASI RAM', '15331A0582.png', 'APSRTC CONDUCTOR', '15331A0582', 'male', 'BTECH', 'cse', 2015, 'vinnu@protonmail.com', '9966529064', 'vizianagaram', 'HTML', 'HTML', 'yes', '', 'SL', '2017-06-09'),
('15331A05A5', 'kjjgl', '15331A05A5.png', 'dfag', '15331A05A5', 'female', 'BTECH', '0', 2013, 'a@a.com', '1234567890', 'vishakapataanam', '', '', 'no', '--', '--', '0000-00-00'),
('15331A05B0', 'P Anil Diwakar2', '15331A05B0', 'farmer', '15331A05B0', 'male', 'BTECH', '0', 2000, 'sdfsd@gmail.com', '7095954895', 'vishakapataanam', '', '', 'no', '--', '--', '2017-07-03'),
('15331A05B4', 'p.manasakomali', '15331A05B4.png', 'business', '15331A05B4', 'female', 'BTECH', 'cse', 2015, 'manasakomali1997@gmail.com', '9493997013', 'vizianagaram', 'everything', 'anything', 'no', '--', '--', '1997-12-19'),
('15331A05B5', 'sai', '15331A05B5', 'jhgf', '15331A05B5', 'male', 'BTECH', '0', 2013, 'anil@gmail.com', '7656565656', 'vishakapataanam', 'uygdaiutjhv', 'hjguyv', 'no', '--', '--', '2017-07-23'),
('15331A05B6', 'ravi', '15331A05B6', 'jhdjg', '15331A05B6', 'male', 'BTECH', '0', 2013, 'a@a.com', '7656565656', 'vishakapataanam', 'uywef', 'uykgwd', 'no', '--', '--', '2017-07-23'),
('15331A05B7', 'raju', '15331A05B7', 'ghg', '15331A05B7', 'male', 'BTECH', '0', 2013, 'hgfhg@gmail.com', '7656565656', 'vishakapataanam', 'jyd', 'uyg', 'no', '--', '--', '2017-07-23'),
('15331A05B8', 'P anil diwakar', '15331A05B8', 'farmer', '15331A05B8', 'male', 'BTECH', '0', 2013, 'anildiwakar956@gmail.com', '7095954895', 'vishakapataanam', 'c', 'python', 'no', '--', '--', '2017-07-23'),
('15331A05C0', 'manasakomali', '15331A05C0.png', 'father', '15331A05C0', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C1', 'manasakomali', '15331A05C1.png', 'father', '15331A05C1', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C2', 'manasakomali', '15331A05C2.png', 'father', '15331A05C2', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C3', 'manasakomali', '15331A05C3.png', 'father', '15331A05C3', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C4', 'manasakomali', '15331A05C4.png', 'father', '15331A05C4', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C5', 'manasakomali', '15331A05C5.png', 'father', '15331A05C5', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C6', 'manasakomali', '15331A05C6.png', 'father', '15331A05C6', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C7', 'manasakomali', '15331A05C7.png', 'father', '15331A05C7', 'male', 'BTECH', '', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C8', 'manasakomali', '15331A05C8.png', 'father', '15331A05C8', 'male', 'BTECH', '', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05C9', 'manasakomali', '15331A05C9.png', 'father', '15331A05C9', 'male', 'BTECH', '', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05D0', 'manasakomali', '15331A05D0.png', 'father', '15331A05D0', 'male', 'BTECH', '0', 2014, 'a@a.com', '1234567890', 'vizianagaram', 'rtak', 'ergegt', 'no', '--', '--', '1997-12-23'),
('15331A05H3', 'potti', '15331A05H3.jpg', 'kudgw', '15331A05H3', 'female', 'BTECH', '0', 2013, 'potti@gmail.com', '1234567890', 'vishakapataanam', 'every technology', 'any', 'no', '--', '--', '2017-07-03');

-- --------------------------------------------------------

--
-- Table structure for table `nominations`
--

CREATE TABLE `nominations` (
  `s.no` int(4) NOT NULL,
  `regdno` varchar(11) NOT NULL,
  `President` int(11) DEFAULT NULL,
  `Vice` int(11) DEFAULT NULL,
  `Treasurer` int(11) DEFAULT NULL,
  `Technical` int(11) DEFAULT NULL,
  `Organiser` int(11) DEFAULT NULL,
  `cultural` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nominations`
--

INSERT INTO `nominations` (`s.no`, `regdno`, `President`, `Vice`, `Treasurer`, `Technical`, `Organiser`, `cultural`) VALUES
(27, '15331A05B8', 6, 6, 4, 0, 0, 2),
(29, '15331A05B7', 1, 0, 3, 0, 5, 0),
(30, '15331A05B6', 1, 2, 1, 0, 0, 2),
(31, '15331A05B5', 0, 1, 1, 4, 0, 0),
(33, '', 3, 0, 0, 1, 0, 1),
(35, '15331A05H3', 1, 2, 1, 4, 2, 2),
(37, '14331A0554', 1, 1, 1, 1, 2, 3),
(38, '10331A0563', 1, 1, 1, 1, 2, 1),
(40, '15331A05C0', 1, 1, 1, 1, 1, 1),
(41, '15331A05B4', 4, 1, 1, 1, 1, 1),
(42, '15331A0582', 1, 1, 2, 2, 1, 1),
(48, '15331A0567', 4, 2, 2, 2, 2, 2),
(49, '15331A0497', 0, 0, 0, 0, 0, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Regd` (`Regd`);

--
-- Indexes for table `nominations`
--
ALTER TABLE `nominations`
  ADD PRIMARY KEY (`s.no`),
  ADD UNIQUE KEY `regdno` (`regdno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `nominations`
--
ALTER TABLE `nominations`
  MODIFY `s.no` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `nominations`
--
ALTER TABLE `nominations`
  ADD CONSTRAINT `nominations_ibfk_1` FOREIGN KEY (`regdno`) REFERENCES `details` (`Regd`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
