<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Registration";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}
$rolls=array(0,0,0,0,0,0);
$reg=$_POST['regnum'];
$rolls=array($_POST['p'],$_POST['vp'],$_POST['t'],$_POST['th'],$_POST['o'],$_POST['c']);
echo '<html><body><center><h1>Thanks for Nomination</h1><br>';
//foreach($rolls as $value)
//{
	//$query="insert into $value values('$reg','$uload',0)";
	$query="INSERT INTO nominations VALUES (' ', '$reg','$rolls[0]','$rolls[1]','$rolls[2]','$rolls[3]','$rolls[4]','$rolls[5]' )";
		$result=$conn->query($query);
	echo '<br>';
	if($result){
	//echo "inserted";
	}
 	else {
    ;//echo "Error: " . $result . "<br>" . $conn->error;
}

//}
echo '</center></body></html>';
?>
