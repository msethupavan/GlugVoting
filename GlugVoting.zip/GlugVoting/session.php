<?php
session_start();
echo $_SESSION["president"];
echo $_SESSION["vice"];
echo $_SESSION["tr"];
echo $_SESSION["te"];
echo $_SESSION["o"];
echo $_SESSION["c"];
?>
